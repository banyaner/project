YUI.add('austra-util', function (Y) {
    Y.mix(
	Y.namespace('Austra.Util'),
	{
	    can: function (o) {
		if (this != window) {
		    return Y.mix(this, {
			work: o != null ? function (f) {
			    return f(o);
			} : function (f) {
			    return null;
			}
		    });
		}

		return new Y.Austra.Util.can(o);
	    }
	}
    );
}, '0.0.1', {
    requires: []
});
