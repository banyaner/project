YUI().use('node', 'event', 'io', 'json-parse', function (Y) {
    Y.on('click', function (e) {
	if (!this.hasClass('secured')) {
	    e.preventDefault();

	    var that = this;
	    Y.io(Y.Lang.sub('/property/{id}/bookmark', {id: this.getData('property')}), {
		method: that.hasClass('bookmarked') ? 'DELETE' : 'PUT',
		on: {
		    success: function (_, resp) {
			var data = Y.JSON.parse(resp.responseText);

			if (data.ok)
			    that.toggleClass('bookmarked');
		    }
		}
	    });
	}
    }, '#page.property.show .synopsis .bookmark');

    Y.delegate('click', function (e) {
	var that = this;
	Y.io(Y.Lang.sub('/property/{id}/bookmark', {id: this.getData('property')}), {
	    method: 'DELETE',
	    on: {
		success: function (_, resp) {
		    var data = Y.JSON.parse(resp.responseText);

		    if (data.ok)
			that.ancestor('tr').remove();
		}
	    }
	});
    }, document, '#page.bookmark.index .unbookmark');
});

YUI().use('node','anim','event', function (Y) {
    if (Y.one('#page.property,.show')) {

        Y.on('click', function (e) {
            if(Y.one('.down').getHTML()=='展开'){
                e.preventDefault();
                Y.one('.hide').setStyle('display', 'block');
                Y.one('.down').setHTML('收起');
                Y.one('.down').setStyle('background-image','url("up.png")' );
            }else{
                e.preventDefault();
                Y.one('.hide').setStyle('display', 'none');
                Y.one('.down').setHTML('展开');
                Y.one('.down').setStyle('background-image','url("down.png")' );
            }

        }, '.charge .open');

    }


});
YUI().use('node', 'event', 'handlebars', 'austra-seed', 'picoriver-photograph', 'sortable', 'austra-cascading', function (Y) {
    Y.delegate('click', function (e) {
	e.preventDefault();

	var render = this.getData('render');
	if (!render)
	    this.setData('render', render = Y.Handlebars.compile(Y.one(this.getData('template') || this.next('script[type="text/x-handlebars-templaFte"]')).getHTML()));

	this.insert(render(Y.merge({name: Y.Austra.Seed.next()}, Y.JSON.parse(this.getData('context') || null))), 'before');
    }, document, '.form-group .add');

    Y.delegate('click', function (e) {
	e.preventDefault();

	this.ancestor(Y.Lang.sub('.{class}', { class: this.getData('dismiss') })).remove();
    }, document, '.close[data-dismiss]');

    Y.delegate('click', function (e) {
	e.preventDefault();

	var uploader = this.getData('uploader');
	if (!uploader) {
	    this.setData('uploader', uploader = new Y.Picoriver.Photograph.Uploader(!this.test('.scalar')));

	    var render = Y.Handlebars.compile(Y.one(this.getData('template') || this.next('script[type="text/x-handlebars-template"]')).getHTML());
	    var context = Y.JSON.parse(this.getData('context') || null);
	    var that = this;
	    uploader.on({
		start: function () {
		    if (that.getData('loading-text'))
			$(that.getDOMNode()).button('loading');
		},
		complete: function (e) {
		    if (that.getData('loading-text'))
			$(that.getDOMNode()).button('reset');

		    if (that.test('.scalar'))
			that.siblings(Y.Lang.sub('.{class}', { class: that.getData('dismiss') })).remove();
		    Y.Array.each(e, function (f) {
			that.insert(render(Y.merge(f, { name: Y.Austra.Seed.next() }, context)), 'before');
		    })
		}
	    })
	}

	uploader.exec();
    }, document, '.form-group .add-file');
});

YUI().use('node', 'transition', 'event', 'event-outside', 'json-parse', function (Y) {
    Y.delegate('click', function (e) {
        e.preventDefault();

        this.ancestor('.dropdown').one('.menu').toggleView();
    }, document, '.dropdown .toggle');

    Y.all('.dropdown').on('clickoutside', function (e) {
        e.currentTarget.one('.menu').toggleView(false);
    });

    Y.delegate('click', function (e) {
        this.getAttribute('href') != '#' || e.preventDefault();

        var dropdown = this.ancestor('.dropdown');
        var target = Y.JSON.parse(dropdown.getData('target') || null);
        if (target) {
            for (var k in target)
                Y.one(k).set('value', this.getData(target[k]));
            dropdown.one('.toggle span').set('text', this.get('title') || this.get('text'));
        }
        dropdown.one('.menu').toggleView(false);
    }, document, '.dropdown .menu a');

    Y.delegate('click', function (e) {
        e.preventDefault();

        Y.one('#hd .collapse').toggleClass('expanded');
    }, document, '#hd .toggle');
});

YUI.add('austra-filter', function (Y) {
    function __construct(path, options, clauses) {
	var _that = this,
	    _stash = null;

	reset_all();

	function add_option(name, multiple) {
	    _stash.options[name] = multiple;

	    return reset_clause(name);
	}

	function add_clause(name, value) {
	    if (_stash.options[name])
		_stash.clauses[name].push(value);
	    else
		_stash.clauses[name] = value;

	    return refresh();
	}

	function reset_clause(name) {
	    _stash.clauses[name] = _stash.options[name] ? [] : null;

	    return refresh();
	}

	function reset() {
	    for (var name in _stash.options)
		reset_clause(name);

	    return refresh();
	}

	function reset_all() {
	    _stash = {
		options: Y.clone(options || {}),
		clauses: Y.clone(clauses || {}),
		current: 1
	    };

	    return refresh();
	}

	function navigate(page) {
	    _stash.current = page;

	    return refresh();
	}

	var timer = null;
	var io = null;
	function refresh() {
	    timer && timer.cancel();
	    io && io.abort();

	    timer = Y.later(150, null, function () {
		_that.fire('start', _stash.clauses);

		io = Y.io(Y.Lang.sub(path, {page: _stash.current}), {
		    data: _stash.clauses,
		    on: {
			success: function (_, r) {
			    _that.fire('complete', Y.JSON.parse(r.responseText));
			}
		    }
		});
	    });

	    return _that;
	}

	return Y.mix(this, {
	    add_option: add_option,
	    add_clause: add_clause,
	    reset_clause: reset_clause,
	    reset: reset,
	    reset_all: reset_all,
	    navigate: navigate
	});
    }

    Y.mix(
	Y.namespace('Austra'),
	{
	    Filter: Y.augment(__construct, Y.EventTarget)
	}
    );
}, '0.0.1', {
    requires: ['event-custom', 'io', 'json-parse']
});

YUI().use('node', 'austra-filter', function (Y) {
});

YUI().use('node', 'event', function (Y) {
    Y.on('click', function (e) {
	e.preventDefault();

	Y.one('#page').addClass('banner').addClass('popup');
    }, '#page.home .banner-hand');

    Y.on('click', function (e) {
	e.preventDefault();

	Y.one('#page').removeClass('banner').removeClass('popup');
    }, '#page.home .banner .close');
});

YUI().use('node', 'event', function (Y) {
    Y.on('click', function (e) {
	e.preventDefault();

	Y.one('#page').addClass('locate').addClass('popup');
    }, '#locale');

    Y.on('click', function (e) {
	e.preventDefault();

	Y.one('#page').removeClass('locate').removeClass('popup');
    }, '#locator .close');
});



    YUI().use('node', 'json-parse', 'event', 'io', 'json-parse', function (Y) {

    if (Y.one('#page.profile')) {

        Y.on('click', function (e) {
            name = Y.one(".mobile input ").get('value');
            var reg = new RegExp("^[0-9]*$");
            if(name.length > 10 && reg.test(name) && name.indexOf("+86") <= 0){
                Y.one(".mobile input ").set("value",'+86 '+name);

            }

        }, '#page.profile .submit');



    }


    });
YUI().use('node', 'austra-util', function (Y) {
    if (Y.one('#page.map, #map')) {
	window.google_maps_ready = function () {
	    var map = null;

	    Y.all('#page.property.map #bd .list li').each(function (p) {
		if (p.getData('latitude') && p.getData('longitude')) {
		    var geo = new google.maps.LatLng(p.getData('latitude'), p.getData('longitude'));
		    if (!map)
			map = new google.maps.Map(Y.one('#page.property.map #bd .map').getDOMNode(), { center: geo, zoom: 11 });
		    var marker = new google.maps.Marker({
					       position: geo,
					       map: map,
					       title: p.one('b').get('text')
					   });
            var contentString = "<div class='map_text'><table><tr><td colspan='2'><a href='"+p.one('a').get('href')+"' target='_blank' ><h1>"+p.one('h1').get('text')+"</h1></a></td></tr><tr><td><b>"+ p.one('b').get('text')+"</b><p>"+p.one('p').get('text')+"</p></td><td align='right' valign='bottom'><span><a href='"+p.one('a').get('href')+"' target='_blank' >查看详情</a></span></td></tr><tr><td colspan='2'><img src='"+p.one('img').get('src')+"' width='250px'></td></tr></table></div>";
            var infowindow = new google.maps.InfoWindow({
                content: contentString
            });

            google.maps.event.addListener(marker, 'click', function() {
                infowindow.open(marker.get('map'), marker);
            });
		}
	    });

	    Y.Austra.Util.can(Y.one('#page.property.show #map, #page.property.show-map #map, #page.project.show #map, #page.report.area #map')).work(function (map) {
		var geo = new google.maps.LatLng(map.getData('latitude'), map.getData('longitude'));
		var map = new google.maps.Map(map.getDOMNode(), { center: geo, zoom: 12 });
		new google.maps.Marker({
					   position: geo,
					   map: map,
					   title: Y.Austra.Util.can(Y.one('h1')).work(function (h) { return h.get('text'); })
				       });
	    });
	};

	var script = document.createElement('script');
        script.src = Y.Lang.sub('http://ditu.google.cn/maps/api/js?key={key}&sensor=false&callback=google_maps_ready',
            {key: Y.one('input[name="-google-api-key"]').get('value')});
        document.body.appendChild(script);
    }
});


YUI().use('node-core', 'node-data', 'event-delegate', 'austra-gallery', function (Y) {
    Y.on('click', function (e) {
	e.preventDefault();

	var row = Y.one('.photographs .tab-bd .tab.active .row');
	var g = row.getData('gallery');
	if (!g)
	    row.setData('gallery', g = new Y.Austra.Gallery({node: row, step: 3}));

	g.forward();
    }, '#page.project .photographs .next');

    Y.on('click', function (e) {
	e.preventDefault();

	var g = Y.one('.photographs .tab-bd .tab.active .row').getData('gallery');

	g && g.backward();
    }, '#page.project .photographs .prev');

    var PER_PAGE	= 5;	// gallery

    function activate(img) {
	var thumbnail	= Y.one('.gallery .thumbnail');
	var frame	= thumbnail.all('li');
	var previous	= frame.filter('.previous');
	var forward	= frame.indexOf(img.ancestor('li'));

	if (forward < previous.size() || previous.size() + PER_PAGE <= forward) {
	    var g = thumbnail.getData('gallery');
	    if (!g)
		thumbnail.setData('gallery', g = new Y.Austra.Gallery({node: thumbnail.one('ul'), step: PER_PAGE}));

	    forward += PER_PAGE / 2;
	    if (frame.size() <= forward)
		forward = frame.size() - 1;
	    forward -= PER_PAGE - 1;
	    if (forward < 0)
		forward = 0;

	    if (previous.size() < forward)
		g.forward(forward - previous.size());
	    else
		g.backward(previous.size() - forward + 1);
	}

	frame.removeClass('active');

	var localname = img.get('src').split('/').pop();
	var p = Y.one('.gallery .large').addClass('loading').one('.f').setData('localname', localname);
	Y.one('.gallery .large .original').set('href', img.getData('original'));

	img.ancestor('li').addClass('active');

	large = Y.Node.create('<img>');
	large.once('load', function () {
	    if (p.getData('localname') == localname) {
		p.insert(Y.Node.create('<div class="f"></div>').append(large), 'before')
		    .transition({
			opacity: 0,
			duration: .35
		    }, function () {
			p.remove();
		    }).
		    ancestor('.large').removeClass('loading');
	    }
	});

	large.set('src', img.getData('large'));
    }

    Y.on('click', function () {
	var that = this;

	var photographs	= this.ancestor('.photographs');
	var gallery	= Y.Node.create(
	    Y.Lang.sub('<div class="gallery">' +
		       '<h2>{heading}</h2>' +
		       '<a href="#" class="close"></a>' +
		       '<div class="large">' +
		       '<div class="f">' +
		       '<img src="{src}">' +
		       '</div>' +
		       '<a href="#" class="prev"><i></i></a>' +
		       '<a href="#" class="next"><i></i></a>' +
		       '<a href="{original}" target="_blank" class="original">查看原图</a>' +
		       '<img src="loading.gif" class="progress">' +
		       '</div>' +
		       '<div class="wrap">' +
		       '<div class="thumbnail">' +
		       '<div><ul></ul></div>' +
		       '<a href="#" class="prev"><i></i></a>' +
		       '<a href="#" class="next"><i></i></a>' +
		       '</div>' +
		       '</div>' +
		       '</div>',
		       {
			   heading: photographs.one('h2').getData('heading'),
			   src: this.getData('large'),
			   original: this.getData('original')
		       })
	);

	var thumbnail	= gallery.one('.thumbnail ul');
	photographs.all('.frame img').each(function () {
	    var f = Y.Node.create('<li></li>').append(this.cloneNode());
	    if (this == that)
		f.addClass('active');
	    thumbnail.append(f);
	});

	Y.one('#page').addClass('popup').append(gallery);
	activate(Y.one('.gallery .thumbnail li.active img'));
    }, '#page.project .photographs img');

    Y.delegate('click', function (e) {
	e.preventDefault();

	this.ancestor('.gallery').remove();
	Y.one('#page').removeClass('popup');
    }, '#page.project', '.gallery .close');

    Y.delegate('click', function () {
	activate(this);
    }, '#page.project', '.gallery .thumbnail img');

    Y.delegate('click', function (e) {
	e.preventDefault();

	var prev = Y.one('.gallery .thumbnail li.active').previous('li');
	prev && activate(prev.one('img'));
    }, '#page.project', '.gallery .large .prev');

    Y.delegate('click', function (e) {
	e.preventDefault();

	var next = Y.one('.gallery .thumbnail li.active').next('li');
	next && activate(next.one('img'));
    }, '#page.project', '.gallery .large .next');

    Y.delegate('click', function (e) {
	e.preventDefault();

	var thumbnail = Y.one('.gallery .thumbnail');
	var g = thumbnail.getData('gallery');
	if (!g)
	    thumbnail.setData('gallery', g = new Y.Austra.Gallery({node: thumbnail.one('ul'), step: PER_PAGE}));

	g.forward() && activate(Y.one('.gallery .thumbnail li:not(.previous) img'));
    }, '#page.project', '.gallery .thumbnail .next');

    Y.delegate('click', function (e) {
	e.preventDefault();

	var g = Y.one('.gallery .thumbnail').getData('gallery');

	g && g.backward() && activate(Y.one('.gallery .thumbnail li:not(.previous) img'));
    }, '#page.project', '.gallery .thumbnail .prev');
});

YUI().use('node-core', 'node-data', 'event-delegate', 'austra-gallery', function (Y) {
    Y.on('click', function () {
	var localname = Y.one("#page .tab-bd .active .slides .active").getAttribute("src").split('/').pop();

	Y.all('.gallery .slides img').
	    removeClass('active').
	    filter(Y.Lang.sub('[src$="{localname}"]', {localname: localname})).
	    addClass('active');
        Y.one(".gallery").setStyle("display", "block");
        Y.one("#page").addClass("popup");
    }, '#page.property .slides .sentinel');

    Y.on('click', function (e) {
        e.preventDefault();

        this.ancestor('.gallery').setStyle("display", "none");
        Y.one('#page').removeClass('popup');
    }, '#page.property .gallery .close');
});

YUI().use('node', 'anim', 'dom-style', 'event-hover', 'gallery-timer', 'austra-util', function (Y) {
    Y.Austra.Util.can(Y.one('#page.home #bd .recommend')).
	work(function (recommend) {
		 var first = recommend.one('.property:first-child'),
		     last = recommend.one('.property:last-child');
		 if (0 < first.getX() &&
		     last.getX() + parseInt(last.getComputedStyle('width')) < parseInt(recommend.getComputedStyle('width')))
		     recommend.all('.prev, .next').toggleView(false);
		 else {
		     var l = recommend.one('ul');

		     if (parseInt(l.getComputedStyle('width')) < parseInt(recommend.getComputedStyle('width')) + 1500) {
			 var q = recommend.all('.property');
			 q.each(function (p) {
			     l.insertBefore(p.cloneNode(true), q.item(0));
			     l.append(p.cloneNode(true));
			 });
			 l.setStyle('left', parseInt(l.getStyle('left')) - 500 * q.size());
			 recommend.one('.fx').setStyle('width', 500 * q.size() * 3);
		     }

		     function slide(back) {
			 if (back) {
			     var p = recommend.one('.property:last-child');
			     l.prepend(p);
			     p.setStyle('width', 0);
			     new Y.Anim({
					    node: p,
					    to: { width: 500 },
					    duration: .35,
					    easing: 'easeBoth'
					}).run();
			 }
			 else {
			     recommend.all('.property').some(function (p) {
                    
				 if (parseInt(p.getStyle('width')) < 500)
				     return false;

				 new Y.Anim({
						node: p,
						to: { width: 0 },
						duration: .35,
						easing: 'easeBoth'
					    }).run().on('end', function () {
							    p.setStyle('width', null);
							    l.append(p);
							});

				 return true;
			     });
			 }
		     }

		     Y.on('click', function (e) {
			 e.preventDefault();

			 slide();
		     }, '.recommend .next');

		     Y.on('click', function (e) {
			 e.preventDefault();

			 slide(true);
		     }, '.recommend .prev');


		     var autoPlay = new Y.Timer({
						    length: 3500,
						    repeatCount: 0
						});

		     autoPlay.after('timer', function (e) {
			 slide();
		     });

		     autoPlay.start();

		     recommend.on('hover', function (e) {
			 autoPlay.pause()
		     }, function (e) {
			 autoPlay.resume()
		     });
		 }
	     });

});



YUI().use('node', 'anim', 'dom-style', 'event-hover', 'gallery-timer', 'austra-util', function (Y) {
    Y.Austra.Util.can(Y.one('#page.property.show #bd .recommend')).
        work(function (recommend) {
            var first = recommend.one('.property:first-child'),
                last = recommend.one('.property:last-child'),
                li_width = 180;


            if (0 < first.getX() &&
                last.getX() + parseInt(last.getComputedStyle('width')) < parseInt(recommend.getComputedStyle('width')))
                recommend.all('.prev, .next').toggleView(false);
            else {
                var l = recommend.one('ul');

                if (parseInt(l.getComputedStyle('width')) < parseInt(recommend.getComputedStyle('width')) + li_width * 3) {
                    var q = recommend.all('.property');
                    q.each(function (p) {
                        l.insertBefore(p.cloneNode(true), q.item(0));
                        l.append(p.cloneNode(true));
                    });
                    l.setStyle('left', parseInt(l.getStyle('left')) - li_width * q.size());
                    recommend.one('.fx').setStyle('width', li_width * q.size() * 3);
                }

                function slide(back) {
                    if (back) {
                        var p = recommend.one('.property:last-child');
                        l.prepend(p);
                        p.setStyle('width', 0);
                        new Y.Anim({
                            node: p,
                            to: { width: li_width },
                            duration: .35,
                            easing: 'easeBoth'
                        }).run();
                    }
                    else {
                        recommend.all('.property').some(function (p) {
                            if (parseInt(p.getStyle('width')) < li_width)
                                return false;

                            new Y.Anim({
                                node: p,
                                to: { width: 0 },
                                duration: .35,
                                easing: 'easeBoth'
                            }).run().on('end', function () {
                                    p.setStyle('width', null);
                                    l.append(p);
                                });

                            return true;
                        });
                    }
                }

                Y.on('click', function (e) {
                    e.preventDefault();

                    slide();
                }, '.recommend-content .next');

                Y.on('click', function (e) {
                    e.preventDefault();

                    slide(true);
                }, '.recommend-content .prev');


                var autoPlay = new Y.Timer({
                    length: 3500,
                    repeatCount: 0
                });

                autoPlay.after('timer', function (e) {
                    slide();
                });

                autoPlay.start();

                recommend.on('hover', function (e) {
                    autoPlay.pause()
                }, function (e) {
                    autoPlay.resume()
                });
            }
        });

});



YUI().use('node', 'anim', 'dom-style', 'event-hover', 'gallery-timer', 'austra-util', function (Y) {
    Y.Austra.Util.can(Y.one('#page.property.show #bd .gallary')).
        work(function (recommend) {
            var first = recommend.one('.property:first-child'),
                last = recommend.one('.property:last-child'),
                li_width = 120;


            if (0 < first.getX() &&
                last.getX() + parseInt(last.getComputedStyle('width')) < parseInt(recommend.getComputedStyle('width')))
                recommend.all('.prev, .next').toggleView(false);
            else {
                var l = recommend.one('ul');

                if (parseInt(l.getComputedStyle('width')) < parseInt(recommend.getComputedStyle('width')) + li_width * 5) {
                    var q = recommend.all('.property');

                    recommend.one('.fx').setStyle('width', li_width * q.size() * 5);
                }

                function slide(back) {
                    if (back) {
                        var p = recommend.one('.property:last-child');
                        l.prepend(p);
                        p.setStyle('width', 0);
                        new Y.Anim({
                            node: p,
                            to: { width: li_width },
                            duration: .35,
                            easing: 'easeBoth'
                        }).run();
                    }
                    else {
                        recommend.all('.property').some(function (p) {
                            if (parseInt(p.getStyle('width')) < li_width)
                                return false;

                            new Y.Anim({
                                node: p,
                                to: { width: 0 },
                                duration: .35,
                                easing: 'easeBoth'
                            }).run().on('end', function () {
                                    p.setStyle('width', null);
                                    l.append(p);
                                });

                            return true;
                        });
                    }
                }

                Y.on('click', function (e) {
                    e.preventDefault();

                    slide();
                }, '.gallary-content .next');

                Y.on('click', function (e) {
                    e.preventDefault();

                    slide(true);
                }, '.gallary-content .prev');


                var autoPlay = new Y.Timer({
                    length: 3500,
                    repeatCount: 0
                });

                autoPlay.after('timer', function (e) {
                    slide();
                });

                autoPlay.start();

                recommend.on('hover', function (e) {
                    autoPlay.pause()
                }, function (e) {
                    autoPlay.resume()
                });
            }
        });

});





YUI().use('node', 'anim', 'dom-style', 'event-hover', 'gallery-timer', 'austra-util', function (Y) {
    Y.Austra.Util.can(Y.one('#page.property.list #bd .recommend')).
        work(function (recommend) {
            var first = recommend.one('.property:first-child'),
                last = recommend.one('.property:last-child'),
                li_width = 300;


            if (0 < first.getX() &&
                last.getX() + parseInt(last.getComputedStyle('width')) < parseInt(recommend.getComputedStyle('width')))
                recommend.all('.prev, .next').toggleView(false);
            else {
                var l = recommend.one('ul');

                if (parseInt(l.getComputedStyle('width')) < parseInt(recommend.getComputedStyle('width')) + li_width * 3) {
                    var q = recommend.all('.property');
                    q.each(function (p) {
                        l.insertBefore(p.cloneNode(true), q.item(0));
                        l.append(p.cloneNode(true));
                    });
                    l.setStyle('left', parseInt(l.getStyle('left')) - li_width * q.size());
                    recommend.one('.fx').setStyle('width', li_width * q.size() * 3);
                }

                function slide(back) {
                    if (back) {
                        var p = recommend.one('.property:last-child');
                        l.prepend(p);
                        p.setStyle('width', 0);
                        new Y.Anim({
                            node: p,
                            to: { width: li_width },
                            duration: .35,
                            easing: 'easeBoth'
                        }).run();
                    }
                    else {
                        recommend.all('.property').some(function (p) {
                            if (parseInt(p.getStyle('width')) < li_width)
                                return false;

                            new Y.Anim({
                                node: p,
                                to: { width: 0 },
                                duration: .35,
                                easing: 'easeBoth'
                            }).run().on('end', function () {
                                    p.setStyle('width', null);
                                    l.append(p);
                                });

                            return true;
                        });
                    }
                }

                Y.on('click', function (e) {
                    e.preventDefault();

                    slide();
                }, '.recommend-content .next');

                Y.on('click', function (e) {
                    e.preventDefault();

                    slide(true);
                }, '.recommend-content .prev');


                var autoPlay = new Y.Timer({
                    length: 3500,
                    repeatCount: 0
                });

                autoPlay.after('timer', function (e) {
                    slide();
                });

                autoPlay.start();

                recommend.on('hover', function (e) {
                    autoPlay.pause()
                }, function (e) {
                    autoPlay.resume()
                });
            }
        });

});
YUI().use('node', 'json-parse', 'event', 'charts', function (Y) {
    Y.ComboSeries.prototype._defaultLineColors = ["#fc6808", "#979797"];
    Y.ComboSeries.prototype._defaultFillColors = ["#fc6808", "#979797"];
    Y.ComboSeries.prototype._defaultBorderColors = ["#fc6808", "#979797"];
    if (Y.one('#page.report,.area')) {
        var colors = ["#fc6808", "#4685e4", "#4f9f18", "#6c6c6c", "#6c6c6c", "#6c6c6c", "#6c6c6c", "#6c6c6c", "#6c6c6c", "#6c6c6c", "#6c6c6c"];
        var pie1_colors = ["#fc6808", "#f1f1f1"];
        var pie2_colors = ["#4685e4", "#f1f1f1"];
        var pie3_colors = ["#4f9f18", "#f1f1f1"];
        Y.ComboSeries.prototype._defaultSliceColors = ["#fc6808", "#979797"];

        var specifyValues = Y.JSON.parse(Y.one("#area_live").get("value"));
        var pi1Values = [
            {live: specifyValues[0]['category'], percent: specifyValues[0]['percent']},
            {live: "others", percent: 100 - specifyValues[0]['percent']}

        ];
        var pi2Values = [
            {live: specifyValues[1]['category'], percent: specifyValues[1]['percent']},
            {live: "others", percent: 100 - specifyValues[1]['percent']}

        ];
        var pi3Values = [
            {live: specifyValues[2]['category'], percent: specifyValues[2]['percent']},
            {live: "others", percent: 100 - specifyValues[2]['percent']}

        ];
        var colors = ["#FF6600", "#3366CC", "#707070"];

        new Y.Chart({
            render: "#pie1",
            categoryKey: "live",
            seriesKeys: ["percent"],
            dataProvider: pi1Values,
            type: "pie",
            seriesCollection: [
                {
                    categoryKey: "live",
                    valueKey: "percent",
                    styles: {
                        fill: {
                            colors: pie1_colors
                        }
                    }
                }
            ]
        });


        new Y.Chart({
            render: "#pie2",
            categoryKey: "live",
            seriesKeys: ["percent"],
            dataProvider: pi2Values,
            type: "pie",
            seriesCollection: [
                {
                    categoryKey: "live",
                    valueKey: "percent",
                    styles: {
                        fill: {
                            colors: pie2_colors
                        }
                    }
                }
            ]
        });


        new Y.Chart({
            render: "#pie3",
            categoryKey: "live",
            seriesKeys: ["percent"],
            dataProvider: pi3Values,
            type: "pie",
            seriesCollection: [
                {
                    categoryKey: "live",
                    valueKey: "percent",
                    styles: {
                        fill: {
                            colors: pie3_colors
                        }
                    }
                }
            ]
        });

//        var unitValues = Y.JSON.parse(Y.one("#month_price").get("value")!=null?Y.one("#month_price").get("value"):[]);


//        new Y.Chart({dataProvider: unitValues, render: "#month_house",styles: stylesDef});

    }
    if (Y.one('#page .property,.show')) {
        if (Y.one('#year_price')) {

            var stylesDef = {
                graph: {
                    background: {
                        fill: {
                            color: "#fff"
                        },
                        border: {
                            color: "#fff",
                            weight: 1
                        }
                    }
                },
                series: {
                    percent: {
                        area: {
                            color: "#4f9f18"
                        },
                        line: {
                            color: "#4f9f18"
                        },
                        marker: {
                            height: 60,
                            fill: {
                                color: colors
                            }
                        }
                    }
                }
            };
            var myAxes = {

                sales: {
                    type: "numeric",
                    position: "left",
                    keys: ["house", "unit"],
                    labelFormat: {
                        prefix: "$",
                        thousandsSeparator: ","
                    }
                }
            };

            var unitValues = Y.JSON.parse(Y.one("#year_price").get("value"));
            new Y.Chart({dataProvider: unitValues, axes: myAxes, render: "#house_price", styles: stylesDef, seriesCollection: [
                {
                    styles: {
                        line: {
                            weight: 2
                        }
                    }
                },
                {
                    styles: {
                        line: {
                            weight: 2
                        }
                    }
                }

            ]});
        }

    }

});
YUI().use('node', 'event', 'anim', 'transition', 'json-parse', function (Y) {
    // ////////////////////////////////////////////////////////////
    // smooth scrolling
    // ////////////////////////////////////////////////////////////

    var scroll = new Y.Anim({
	node: YUI.Env.UA.webkit > 0 ? Y.one('body') : Y.one('body').ancestor(),
	easing: 'easeBoth'
    });

    function scroll_to(target) {
	function do_scroll(dy) {
	    var cy = Y.one(document).get('scrollTop');
	    if (dy != cy) {
		scroll.setAttrs({
		    to: { scrollTop: dy },
		    duration:.35
		});
		scroll.run();
	    }
	}

	do_scroll(Y.Lang.isNumber(target) ? target : Y.one(target).getY());
    }

    Y.delegate('click', function (e) {
	e.preventDefault();

	if (this.getAttribute('href') != '#' && !this.ancestor('.tab-hd'))
	    scroll_to(this.getAttribute('href'));
    }, document, 'a[href^="#"]');

    (function () {
	// ////////////////////////////////////////////////////////////
	// breakpoint
	// ////////////////////////////////////////////////////////////

	var breakpoints = [];

	Y.all('.scroll-breakpoint').each(function (bp) {
	    var toggle = Y.JSON.parse(bp.getData('toggle'));
	    for (var k in toggle)
		breakpoints.push({
		    y:	    bp.getY(),
		    target: Y.one(k),
		    klass:  toggle[k]
		});
	});

	function toggle() {
	    var y = Y.one(document).get('scrollTop');

	    Y.Array.each(breakpoints, function (bp) {
            bp.target.toggleClass(bp.klass, bp.y < y);
	    });

	}

	Y.on('scroll', function (e) {
	    toggle();
	}, document);

	toggle();
    })();
});

YUI().use('node', 'event', 'austra-weibo', function (Y) {
    Y.delegate('click', function (e) {
	e.preventDefault();

	var text    = this.getData('text') && Y.one(this.getData('text')).get('text'),
	    picture = this.getData('picture') && Y.all(this.getData('picture')).get('src');
	Y.Austra.Weibo.share(text || undefined, picture || undefined, !picture);
    }, document, '.weibo-share');
});

YUI().use('node', 'paginator', 'event-hover', 'event-flick', 'gallery-timer', 'austra-util', function (Y) {
    Y.all('.slideshow').each(function () {
	var slides = this.all('.slide'),
	    controls = this.all('.gallary li'),
        next = this.all('.next'),
        prev = this.all('.prev'),
	    selectedClass = 'active',
	    pg = new Y.Paginator({
		itemsPerPage: 1,
		totalItems: slides.size()
	    });

	pg.after('pageChange', function (e) {
	    var page = e.newVal;

	    page--;
	    slides.removeClass(selectedClass);
	    controls.removeClass(selectedClass);

	    slides.item(page).addClass(selectedClass);
        controls.item(page).addClass(selectedClass);
	});

	this.delegate('click', function (e) {
	    e.preventDefault();
	    var control = e.currentTarget;

	    if (control.hasClass(selectedClass)) {
		return;
	    }

	    pg.set('page', parseInt(control.getData('page'), 10));
	}, '.control');

	this.delegate('click', function (e) {
	    e.preventDefault();

	    pg.prevPage();
	}, '.prev');

	this.delegate('click', function (e) {
	    e.preventDefault();

	    pg.nextPage();
	}, '.next');

	this.on('flick', function (e) {
	    if (e.flick.distance < 0)
		pg.nextPage();
	    else
		pg.prevPage();
	}, { preventDefault: true, axis: 'x' });

	var autoPlay = new Y.Timer({
	    length: 3500,
	    repeatCount: 0
	});

	autoPlay.after('timer', function (e) {
	    if (pg.hasNextPage()) {
		pg.nextPage();
	    }
	    else {
		pg.set('page', 1);
	    }
	});

	autoPlay.start();


	this.on('hover', function (e) {
        next.item(0).setStyle('display','block');
        prev.item(0).setStyle('display','block');

        autoPlay.pause()
	}, function (e) {
        next.item(0).setStyle('display','none');
        prev.item(0).setStyle('display','none');

        autoPlay.resume()
	});
    });
});

YUI().use('node', 'event', function (Y) {
    Y.delegate('click', function (e) {
	e.preventDefault();

	this.ancestor('.tab').addClass('active').
	    siblings('.tab').removeClass('active');
	Y.one(this.getAttribute('href')).addClass('active').
	    siblings('.tab').removeClass('active');
    }, document, '.tab-hd .tab a');
});

YUI().use('node', 'event', function (Y) {
    Y.delegate('click', function (e) {
        e.preventDefault();

        this.ancestor('.tab').addClass('active').
            siblings('.tab').removeClass('active');
        Y.one(this.getAttribute('href')).addClass('active').
            siblings('.tab').removeClass('active');
    }, document, '.tab-li .tab a');
});
