YUI.add('austra-weibo', function (Y) {
    var appkey = Y.config.modules[this.name]['appkey'];

    function dispatch(opts, args, off) {
	off = off || 0;

	var prms = {};

	for (var i in opts) {
	    if (args.length <= off)
		break;

	    var name, type;
	    for (name in opts[i]) {
		type = opts[i][name];
	    }

	    if (typeof(args[off]) != 'undefined' &&
		(typeof(type) != 'function' ?
		 typeof(args[off]) != type :
		 !(args[off] instanceof type)))
		continue;

	    prms[name] = args[off++];
	}

	return prms;
    }

    Y.mix(
	Y.namespace('Austra.Weibo'),
	{
	    share: function (text, picture, discover, options) {
		var args = dispatch([
		    { text	: 'string'  },
		    { picture	:  Array    },
		    { discover	: 'boolean' },
		    { options	: 'object'  }
		], arguments);

		args.options = Y.merge(
		    {
			appkey	  : appkey,
			language  : 'zh_cn',
			searchPic : false,
			url	  : location.href
		    },
		    args.options || {}
		);
		if (typeof(args.text) != 'undefined')
		    args.options.title = args.text;
		if (typeof(args.picture) != 'undefined')
		    args.options.pic = args.picture.slice(0, 3).join('||');
		if (typeof(args.discover) != 'undefined')
		    args.options.searchPic = args.discover;
		args.options.searchPic = String(args.options.searchPic);

		window.open(
		    'http://service.weibo.com/share/share.php?' + Y.QueryString.stringify(args.options),
		    '_blank',
		    'width=400,height=300'
		);
	    }
	}
    );
}, '0.0.1', {
    requires: ['querystring-stringify']
});
