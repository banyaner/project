YUI.add('austra-gallery', function (Y) {
    function Gallery() {
	Gallery.superclass.constructor.apply(this, arguments);
    }

    Gallery.NAME = 'austraGallery';

    Gallery.ATTRS = {
	node: {
	    setter: function (node) {
		return Y.one(node) || Y.fail('Austra.Gallery: Invalid Node Given: ' + node);
	    }
	},
	step: {
	    value: 1
	},
	duration: {
	    value: .35
	}
    };

    function forward(step) {
	step = step || this.get('step');
	var that = this;

	var fs = that.get('node').get('children').filter(':not(.previous)');
	if (fs.size() > step) {
	    function _forward() {
		var f = fs.shift();
		f && f.transition({
		    marginLeft: Y.Lang.sub('-{width}px', { width: f.get('offsetWidth') }),
		    duration: that.get('duration') / step,
		    easing: 'linear'
		}, _forward);
	    }

	    fs = fs.slice(0, step).addClass('previous');
	    fs.each(function () {
		this.setData('marginLeft', this.getStyle('marginLeft'));
	    });
	    _forward();

	    return true;
	}
    }

    function backward(step) {
	step = step || this.get('step');
	var that = this;

	var fs = that.get('node').get('children').filter('.previous');
	if (fs.size() > 0) {
	    function _backward() {
		var f = fs.pop();
		f && f.transition({
		    marginLeft: f.getData('marginLeft'),
		    duration: that.get('duration') / step,
		    easing: 'linear'
		}, _backward);
	    }

	    fs = fs.slice(-step).removeClass('previous');
	    _backward();

	    return true;
	}
    }

    Y.mix(
	Y.namespace('Austra'),
	{
	    Gallery: Y.extend(Gallery, Y.Base, {
		forward: forward,
		backward: backward
	    })
	}
    );
}, '0.0.1', {
    requires: ['base', 'node-core', 'node-style', 'transition']
});
