/*
YUI 3.14.1 (build 63049cb)
Copyright 2013 Yahoo! Inc. All rights reserved.
Licensed under the BSD License.
http://yuilibrary.com/license/
*/

YUI.add("axis-stacked",function(e,t){e.StackedAxis=e.Base.create("stackedAxis",e.NumericAxis,[e.StackedImpl])},"3.14.1",{requires:["axis-numeric","axis-stacked-base"]});
