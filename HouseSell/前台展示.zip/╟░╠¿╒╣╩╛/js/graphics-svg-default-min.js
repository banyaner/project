/*
YUI 3.14.1 (build 63049cb)
Copyright 2013 Yahoo! Inc. All rights reserved.
Licensed under the BSD License.
http://yuilibrary.com/license/
*/

YUI.add("graphics-svg-default",function(e,t){e.Graphic=e.SVGGraphic,e.Shape=e.SVGShape,e.Circle=e.SVGCircle,e.Rect=e.SVGRect,e.Ellipse=e.SVGEllipse,e.Path=e.SVGPath,e.Drawing=e.SVGDrawing},"3.14.1");
