//弹出隐藏层
function ShowDiv(show_div,bg_div){
document.getElementById(show_div).style.display='block';
document.getElementById(bg_div).style.display='block' ;
var bgdiv = document.getElementById(bg_div);
bgdiv.style.width = document.body.scrollWidth;
// bgdiv.style.height = $(document).height();
$("#"+bg_div).height($(document).height());
};
//关闭弹出层
function CloseDiv(show_div,bg_div)
{
document.getElementById(show_div).style.display='none';
document.getElementById(bg_div).style.display='none';
};

		/**退出系统**/
function logout(){
	if(confirm("您确定要退出本系统吗？")){
		window.location.href = "login.htm";
			}
		} 
<!-- 添加房源部分 -->

        $(document).ready(function(){  
    //add method  
    $("#addf").click(function(evt){
        var target=$(evt.currentTarget).parent().parent();  
        var $table = $("#loop tr");  
        var len = $table.length;
            target.after("<tr id=" + len + ">" + "<td>" +   
                " 房型"+"</td>"+"<td>"+"<input type='text' name='shi+" + len + "' id='shi+" + len + "' size='40' />" + "室&nbsp;"+
                "<input type='text' name='wei+" + len + "' id='wei+" + len + "+" + len + "' size='40' />" +"卫"+"&nbsp;&nbsp;&nbsp;价格&nbsp;&nbsp;"+"<input type='text' name='money+" + len + "' id='money+" + len + "' size='40' />" + "澳元" + "</td>" + "</tr>");  
    });  
      
    //sub method  
    $("#subf").click(function(){  
        var len = $("#loop tr").length;  
        if(len > 1)  
            $("tr[id='"+(len-1)+"']").remove();  
    });  
});
<!-- 编辑房源部分 -->

        $(document).ready(function(){  
    //add method  
    $("#addf1").click(function(evt){ 
    var target=$(evt.currentTarget).parent().parent();  
        var $table = $("#loop1 tr");  
        var len = $table.length;
            target.after("<tr id=" + len + ">" + "<td>" +   
                " 房型"+"</td>"+"<td>"+"<input type='text' name='shi1+" + len + "' id='shi1+" + len + "' size='40' />" + "室&nbsp;"+
                "<input type='text' name='wei1+" + len + "' id='wei1+" + len + "' size='40' />" +"卫"+"&nbsp;&nbsp;&nbsp;价格&nbsp;&nbsp;"
                +"<input type='text' name='money1+" + len + "' id='money1+" + len + "' size='40' />" + "澳元" +
                "</td>" + "</tr>");   
    });  
      
    //sub method  
    $("#subf1").click(function(){  
        var len = $("#loop1 tr").length;  
        if(len > 1)  
            $("tr[id='"+(len-1)+"']").remove();  
    });  
});
<!-- 添加图片部分 -->

        $(document).ready(function(){  
    //add method  
    $("#addp").click(function(evt){ 
    var target=$(evt.currentTarget).parent().parent();  
        var $table = $("#loop tr");  
        var len = $table.length;
        target.after("<tr id=" + len + ">" + "<td>" +   
                " 上传图片"+"</td>"+"<td>"+"<input type='file' name='upload+" + len + "' id='upload+" + len + "' size='40' />" +   
                "</td>" + "</tr>");  
    });  
        //sub method  
    $("#subp").click(function(){  
        var len = $("#loop tr").length;  
        if(len > 1)  
            $("tr[id='"+(len-1)+"']").remove();  
    });  
});
<!-- 编辑图片部分 -->

        $(document).ready(function(){  
    //add method  
    $("#addp1").click(function(evt){ 
    var target=$(evt.currentTarget).parent().parent();  
        var $table = $("#loop1 tr");  
        var len = $table.length;
        target.after("<tr id=" + len + ">" + "<td>" +   
                " 上传图片"+"</td>"+"<td>"+"<input type='file' name='upload1+" + len + "' id='upload1+" + len + "' size='40' />" +   
                "</td>" + "</tr>");  
    });  
        $("#subp1").click(function(){  
        var len = $("#loop1 tr").length;  
        if(len > 1)  
            $("tr[id='"+(len-1)+"']").remove();  
    });  
});